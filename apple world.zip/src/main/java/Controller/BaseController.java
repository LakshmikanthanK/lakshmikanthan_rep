package Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BaseController {

	@RequestMapping("/")
	public String goHome(){
		System.out.println("In Controller");
		return "index";
	}
	@RequestMapping("/Login")
	public String goLogin(){
		System.out.println("In Login");
		return "Login";
		
	}
	
	@RequestMapping("/Support")
	public String goSupport(){
		System.out.println("In Support");
		return "Support";
	}
	
}

package Model;

import javax.persistence.Column;

import org.hibernate.annotations.Entity;

@Entity
public class CategoryModel {
	@Column
    private String code;
    @Column
    private String name;
    @Column
    private String price;
    @Column
    private String edit;
    @Column
    private String delete;
    
    public String getcode () {
        return code;
    }

    public void setcode (String code) {
        this.code = code;
    }  
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getEdit() {
        return edit;
    }

    public void setEdit(String edit) {
        this.edit = edit;
    }

    public String getDelete() {
        return delete;
    }

    public void setDelete(String delete) {
        this.delete = delete;
    }
}
       

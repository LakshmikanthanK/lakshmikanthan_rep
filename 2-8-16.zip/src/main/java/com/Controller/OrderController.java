package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.OrderDAO;
import com.Model.Order1;

@Controller
public class OrderController {
	
	@Autowired
	OrderDAO od;
	@RequestMapping("/checkout")
	public ModelAndView gocheckout(){
		ModelAndView view = new ModelAndView("checkout");
		view.addObject("orderobj",new Order1());
		System.out.println("In checkout");
		return view;
	}

}

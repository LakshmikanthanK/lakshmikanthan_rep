package com.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BaseController {

	
	@RequestMapping("/login")
	public String goaccess(){
		System.out.println("In Login");
		return "login";
		
	}
		
	@RequestMapping("/customerfi")
	public String goSupport(){
		System.out.println("customerfi");
		return "customerfi";
	}
	
	
	@RequestMapping("/adminfi")
	public String goadminfi(){
		System.out.println("adminfi");
		return "adminfi";
	}
	
	
	@RequestMapping("/cart")
	public String gocart(){
		System.out.println("In cart");
		return "cart";
	}
	
	
	
	@RequestMapping("/shop")
	public String goshop(){
		System.out.println("In shop");
		return "shop";
	}
	
	@RequestMapping("/Register1")
	public String goRegister1(){
		System.out.println("In Register1");
		return "Register1";
	}
	@RequestMapping("/contact-us")
	public String gocontactus(){
		System.out.println("In contact-us");
		return "contact-us";
		
	}
	@RequestMapping("/productdetails")
	public String goproductdetails(){
		System.out.println("In productdetails");
		return "productdetails";
	}
	@RequestMapping("/order")
	public String goorder(){
		System.out.println("In order");
		return "order";
	}
	@RequestMapping("/payment")
	public String gopayment(){
		System.out.println("In payment");
		return "payment";
	}
	
	
	
	@RequestMapping("/logout")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
	ModelAndView view = new ModelAndView("front");
	request.getSession().invalidate();
	return view;
	} 
	
	
}

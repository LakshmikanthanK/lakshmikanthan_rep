package com.DAO;

public class ShippingDAO {

}

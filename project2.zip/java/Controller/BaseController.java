package Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BaseController {

	
	@RequestMapping("/slide")
	public String goslide(){
		return "slide";
	}
	@RequestMapping("/")
	public String goMenu(){
		return "Menu";
	}
	
		@RequestMapping("/login")
	public String gologin(){
			return "login";
	}
	
	@RequestMapping("/register")
	public String goregister(){
			return "register";
	}
	
	
}


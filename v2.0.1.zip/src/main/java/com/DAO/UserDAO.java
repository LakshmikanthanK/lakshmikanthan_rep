package com.DAO;

import java.util.List;

import com.Model.User;

public interface UserDAO {
	void addUser(User u);
	User viewUserby(String uname);

}

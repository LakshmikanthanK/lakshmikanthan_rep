/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.Model.User;


/**
 * @author Admin
 *
 */
@Repository
public class UserDAOImpl implements UserDAO {

	/* (non-Javadoc)
	 * @see com.DAO.UserDAO#addUser(com.Model.User)
	 */

	@Autowired
	SessionFactory sf;
	
	Session s;
	Transaction t;
	@Transactional
	@Override
	public void addUser(User u) {
		// TODO Auto-generated method stub
		
		s = sf.openSession();
		t = s.beginTransaction();
		u.setRole("ROLE_USER");
		u.setEnabled(true);
		s.saveOrUpdate(u);
		t.commit();

	}
	/* (non-Javadoc)
	 * @see com.DAO.UserDAO#viewUser()
	 */
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public User  viewUserby(String uname) {
		// TODO Auto-generated method stub
		Session s;
		/*
		 * if(sf.getCurrentSession()!=null) { s=sf.getCurrentSession(); } else
		 */
		s = sf.openSession();
		Transaction t = s.beginTransaction();
		User  u = (User ) s.load(User .class, uname);
		t.commit();
		return u;
	
	}

}

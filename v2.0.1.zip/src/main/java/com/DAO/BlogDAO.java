package com.DAO;

import java.util.List;

import com.Model.Blog;


public interface BlogDAO {

		void addBlog(Blog b);
		List<Blog> viewBlog();
}

package com.Model;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;



	@Entity
	public class User {

		@Column
		private String uname;
		@Id
		@Column
		private String youmail;
		@Column
		private String dob;
		@Column
		private String youpasswd;
		@Column
		private String pnumber;		
		@Column
		private boolean enabled;
		@Column
		private String role;
		 @Transient
		private MultipartFile file;
		public String getUname() {
			return uname;
		}
		public void setUname(String uname) {
			this.uname = uname;
		}
		public String getYoumail() {
			return youmail;
		}
		public void setYoumail(String youmail) {
			this.youmail = youmail;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getYoupasswd() {
			return youpasswd;
		}
		public void setYoupasswd(String youpasswd) {
			this.youpasswd = youpasswd;
		}
		public String getPnumber() {
			return pnumber;
		}
		public void setPnumber(String pnumber) {
			this.pnumber = pnumber;
		}
		public boolean isEnabled() {
			return enabled;
		}
		public void setEnabled(boolean enabled) {
			this.enabled = enabled;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public MultipartFile getFile() {
			return file;
		}
		public void setFile(MultipartFile file) {
			this.file = file;
		}
	}

package com.Model;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

public class Order1 implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue
    
    public int customerOrderId;
    @OneToOne
    @JoinColumn(name="cartId")
    public  Cart cart;
    @OneToOne
    @JoinColumn(name="id")
    public Customer user;
    @OneToOne
    @JoinColumn(name="billingAddressId")
    public BillingAddress billingAddress;
    @OneToOne
    @JoinColumn(name="shippingAddressId")
    public Shipping shippingAddress;
    public int getCustomerOrderId() {
        return customerOrderId;
    }
    public void setCustomerOrderId(int customerOrderId) {
        this.customerOrderId = customerOrderId;
    }
    public Cart getCart() {
        return cart;
    }
    public void setCart(Cart cart) {
        this.cart = cart;
    }
    
    public Customer getUser() {
        return user;
    }
    public void setUser(Customer user) {
        this.user = user;
    }
    public BillingAddress getBillingAddress() {
        return billingAddress;
    }
    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }
    public Shipping getShippingAddress() {
        return shippingAddress;
    }
    public void setShippingAddress(Shipping shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
    

}
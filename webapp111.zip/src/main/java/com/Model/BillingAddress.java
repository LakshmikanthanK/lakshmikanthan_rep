package com.Model;

	import java.io.Serializable;

	import javax.persistence.GeneratedValue;
	import javax.persistence.Id;
	import javax.persistence.OneToOne;

	public class BillingAddress implements Serializable {

	    /**
	     * 
	     */
	    private static final long serialVersionUID = 1L;
	    
	    @Id
	    @GeneratedValue
	    public int billingAddressId;
	    public String streetName;
	    public String apartmentNumber;
	    public String city;
	    public String state;
	    public String country;
	    public String zipcode;
	    @OneToOne
	    public Customer user;

	    public int getBillingAddressId() {
	        return billingAddressId;
	    }

	    public void setBillingAddressId(int billingAddressId) {
	        this.billingAddressId = billingAddressId;
	    }

	    public String getStreetName() {
	        return streetName;
	    }

	    public void setStreetName(String streetName) {
	        this.streetName = streetName;
	    }

	    public String getApartmentNumber() {
	        return apartmentNumber;
	    }

	    public void setApartmentNumber(String apartmentNumber) {
	        this.apartmentNumber = apartmentNumber;
	    }

	    public String getCity() {
	        return city;
	    }

	    public void setCity(String city) {
	        this.city = city;
	    }

	    public String getState() {
	        return state;
	    }

	    public void setState(String state) {
	        this.state = state;
	    }

	    public String getCountry() {
	        return country;
	    }

	    public void setCountry(String country) {
	        this.country = country;
	    }

	    public String getZipcode() {
	        return zipcode;
	    }

	    public void setZipcode(String zipcode) {
	        this.zipcode = zipcode;
	    }

	    public Customer getUser() {
	        return user;
	    }

	    public void setUser(Customer user) {
	        this.user = user;
	    }

	    
	    

	}


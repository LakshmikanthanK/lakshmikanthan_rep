package com.DAO;

public interface Order1DAO {

}

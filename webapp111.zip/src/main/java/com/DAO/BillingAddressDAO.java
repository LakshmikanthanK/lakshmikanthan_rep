package com.DAO;

import com.Model.BillingAddress;

public interface BillingAddressDAO {
	
	void addBillingAddress(BillingAddress b);
	BillingAddress viewBillingAddress(String id);

}

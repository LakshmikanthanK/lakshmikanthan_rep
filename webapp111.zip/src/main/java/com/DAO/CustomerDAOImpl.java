package com.DAO;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Model.Customer;

@Repository("CustomerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	SessionFactory sf;

	public void addCustomer(Customer c) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		c.setEnabled(true);
		c.setRole("ROLE_USER");
		s.save(c);
		t.commit();
		
	}

	public void delCustomer(String emailId) {
		// TODO Auto-generated method stub
		
	}

	public void updCustomer(Customer c) {
		// TODO Auto-generated method stub
		
	}

	public List<Customer> viewCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	public Customer viewCustomerByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}

package com.DAO;

import java.util.List;

import com.Model.SupplierModel;

public interface SupplierDAO { 
	void addSupplier(SupplierModel p);
    
    void deleteSupplier(SupplierModel p);
    
    List<SupplierModel>ViewSupplierModel();
    SupplierModel viewSupplierby(String code);
}


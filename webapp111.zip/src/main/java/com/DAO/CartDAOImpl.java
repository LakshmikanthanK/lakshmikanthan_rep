/**
 * 
 */
package com.DAO;

import java.io.IOException;

import com.Model.Cart;

/**
 * @author deepak
 *
 */
public class CartDAOImpl implements CartDAO {

	/* (non-Javadoc)
	 * @see com.DAO.CartDAO#getCartById(int)
	 */
	@Override
	public Cart getCartById(int cartId) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.DAO.CartDAO#validate(int)
	 */
	@Override
	public Cart validate(int cartId) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.DAO.CartDAO#update(com.Model.Cart)
	 */
	@Override
	public void update(Cart cart) {
		// TODO Auto-generated method stub

	}

}

/**
 * 
 */
package com.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.BillingAddress;

/**
 * @author deepak
 *
 */
@Repository
@Transactional
public class BillingAddressImpl implements BillingAddressDAO {

	/* (non-Javadoc)
	 * @see com.DAO.BillingAddressDAO#addBillingAddress(com.Model.BillingAddress)
	 */
	@Autowired
	SessionFactory sf;
	@Transactional
	@Override
	public void addBillingAddress(BillingAddress b) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(b);
		t.commit();

	}

	/* (non-Javadoc)
	 * @see com.DAO.BillingAddressDAO#viewBillingAddress(java.lang.String)
	 */
	@Transactional
	@Override
	public BillingAddress viewBillingAddress(String id) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		BillingAddress b = (BillingAddress)s.load(BillingAddress.class, id);
		t.commit();
		return b;
	}

}

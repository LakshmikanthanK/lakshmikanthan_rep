/**
 * 
 */
package com.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.BillingAddress;
import com.Model.Shipping;

/**
 * @author deepak
 *
 */
@Repository
@Transactional
public class ShippingDAOImpl implements ShippingDAO {

	/* (non-Javadoc)
	 * @see com.DAO.ShippingDAO#addshipping(com.Model.Shipping)
	 */
	@Autowired
	SessionFactory sf;
	@Transactional
	@Override
	public void addshipping(Shipping sh) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(sh);
		t.commit();

	}

	/* (non-Javadoc)
	 * @see com.DAO.ShippingDAO#viewShippingby(java.lang.String)
	 */
	@Transactional
	@Override
	public Shipping viewShippingby(String id) {
		// TODO Auto-generated method stub
		
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		Shipping sh = (Shipping)s.load(Shipping.class, id);
		t.commit();
		return sh;
		
	}

}

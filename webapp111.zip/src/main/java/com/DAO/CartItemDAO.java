package com.DAO;

public interface CartItemDAO {

}

package com.DAO;


import com.Model.Shipping;

public interface ShippingDAO {

	void addshipping(Shipping sh);
	Shipping  viewShippingby(String id);
}

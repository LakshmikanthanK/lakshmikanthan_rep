package com.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BaseController {

	@RequestMapping("/")
	public String goHome(){
		System.out.println("In Controller");
		return "front";
	}
	@RequestMapping("/access")
	public String goaccess(){
		System.out.println("In Login");
		return "access";
		
	}
		
	@RequestMapping("/customerfi")
	public String goSupport(){
		System.out.println("customerfi");
		return "customerfi";
	}
	
	
	@RequestMapping("/adminfi")
	public String goadminfi(){
		System.out.println("adminfi");
		return "adminfi";
	}
	
	
	@RequestMapping("/shop")
	public String goshop(){
		System.out.println("In shop");
		return "shop";
	}
	
	@RequestMapping("/cart")
	public String gocart(){
		System.out.println("In cart");
		return "cart";
	}
	
	
	@RequestMapping("/logout")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
	ModelAndView view = new ModelAndView("front");
	request.getSession().invalidate();
	return view;
	} 
	
	
}

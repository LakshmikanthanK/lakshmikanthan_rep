package com.Controller;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class BaseController {

	
	@RequestMapping("/")
	public String gouserprofile(){
		System.out.println("userprofile");
		return "userprofile";
			}	
			@RequestMapping("/404")
			public String go404(){
				System.out.println("404");
				return "404";
				
			}
			@RequestMapping("/login")
			public String gologin(){
				System.out.println("login");
				return "login";
			}
			@RequestMapping("/chat")
			public String gochat(){
				System.out.println("chat");
				return "chat";
			}
	
	
	
	
	
	//@RequestMapping("/logout")
	//public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
	//ModelAndView view = new ModelAndView("front");
	//request.getSession().invalidate();
	//return view;
	//} 
	
	
}

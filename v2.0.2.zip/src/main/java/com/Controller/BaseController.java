package com.Controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.BlogDAO;
import com.DAO.UserDAO;
import com.Model.Blog;
import com.Model.User;

@Controller
public class BaseController {

	@Autowired
	UserDAO ud;
	@Autowired
	BlogDAO bd;

	@ModelAttribute("obj")
	public User getOb() {
		return new User();
	}

	@RequestMapping("/")
	public String gouserprofile() {
		System.out.println("userprofile");
		return "userprofile";
	}

	@RequestMapping(value = "/save")
	public ModelAndView dohome1(@ModelAttribute("obj") User x, HttpServletRequest req) {
		ModelAndView m = new ModelAndView("home");
		ud.addUser(x);
		if (!x.getFile().isEmpty()) {
			String a = req.getSession().getServletContext().getRealPath("/");
			File f = new File(a + "\\resources\\assets\\upimages\\");
			if (!f.exists())
				f.mkdirs();
			Path path = Paths.get(a + "\\resources\\assets\\upimages\\" + x.getUname() + ".jpg");
			try {
				x.getFile().transferTo(new File(path.toString()));
				System.out.println(path.toString());
			} catch (Exception e) {
			}
		} else {
			m.setViewName("login");
			System.out.println("You failed to upload " + x.getUname() + " because the file was empty.");

		}
		return m;
	}

	@RequestMapping("/view")
	public ModelAndView gopro() {
		ModelAndView m = new ModelAndView("editprofile");
		m.addObject("data",ud.viewUserby(""));
		return m;
	}

	

	@RequestMapping("/login")
	public String gologin() {
		System.out.println("login");
		return "login";
	}

	@RequestMapping("/chat")
	public String gochat() {
		System.out.println("chat");
		return "chat";
	}

	@RequestMapping("/home")
	public String gohome() {
		System.out.println("home");
		return "home";
	}
	
	/*=======================*Blog*========================*/

	
	@ModelAttribute("blo")
	public Blog getblo() {
		return new Blog();
	}
	
	@RequestMapping("/blog")
	public String goblog() {
		System.out.println("blog");
		return "blog";
	}
	@RequestMapping("/createblog")
	public String gocreateblog() {
		System.out.println("createblog");
		return "createblog";
	}
	@RequestMapping("/views")
	public ModelAndView goblo() {
		ModelAndView m = new ModelAndView("blog");
		m.addObject("text", bd.viewBlog());
		return m;
	}

	@RequestMapping("/bloginfo")
	public String gobloginfo() {
		System.out.println("bloginfo");
		return "bloginfo";
	}
	
	
	@RequestMapping(value = "/sav")
	public ModelAndView dohome1(@ModelAttribute("blo") Blog y, HttpServletRequest req) {
		ModelAndView m = new ModelAndView("home");
		bd.addBlog(y);
		if (!y.getFile().isEmpty()) {
			String a = req.getSession().getServletContext().getRealPath("/");
			File f = new File(a + "\\resources\\assets\\upimages\\");
			if (!f.exists())
				f.mkdirs();
			Path path = Paths.get(a + "\\resources\\assets\\upimages\\" + y.getTitle() + ".jpg");
			try {
				y.getFile().transferTo(new File(path.toString()));
				System.out.println("uploaded successfully");
			}
			catch (Exception e) {
			}
		} else {
			m.setViewName("createblog");
			System.out.println("You failed to upload " + y.getTitle() + " because the file was empty.");

		}
		return m;
	}

	
	
	
	@RequestMapping("/contact")
	public String gocontact() {
		System.out.println("contact");
		return "contact";
	}

	@RequestMapping("/services")
	public String goservices() {
		System.out.println("services");
		return "services";
	}

	@RequestMapping("about")
	public String goabout() {
		System.out.println("about");
		return "about";
	}
	@RequestMapping("/404")
	public String go404() {
		System.out.println("404");
		return "404";

	}

	 @RequestMapping("/logout")
	 public ModelAndView handleRequest(HttpServletRequest request,HttpServletResponse response){
		 ModelAndView view = new ModelAndView("home");
		 request.getSession().invalidate();
		 return view;
	 }

}

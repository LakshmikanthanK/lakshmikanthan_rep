/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.Blog;
import com.Model.User;

/**
 * @author Admin
 *
 */
@Repository
public class BlogDAOImpl implements BlogDAO {

	/* (non-Javadoc)
	 * @see com.DAO.BlogDAO#addBlog(com.Model.Blog)
	 */
	@Autowired
	SessionFactory sf;
	
	Session s;
	Transaction t;
	@Transactional

	public void addBlog(Blog b) {
		// TODO Auto-generated method stub

		s = sf.openSession();
		t = s.beginTransaction();
		s.saveOrUpdate(b);
		t.commit();
	}

	/* (non-Javadoc)
	 * @see com.DAO.BlogDAO#viewBlog()
	 */
	@Transactional

	public List<Blog> viewBlog() {
		// TODO Auto-generated method stub
		List<Blog> l;
		s = sf.openSession();
		t = s.beginTransaction();
		l = (List<Blog>)s.createCriteria(Blog.class).list();
		return l;
	}

}

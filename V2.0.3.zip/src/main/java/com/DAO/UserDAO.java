package com.DAO;

import java.util.List;


import com.Model.User;

public interface UserDAO {
	void addUser(User u);
	void editUser(User u);
	User viewUserby(String uname);
	List<User> viewAll();
}

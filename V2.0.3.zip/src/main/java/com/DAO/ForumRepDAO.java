package com.DAO;

import com.Model.ForumRep;
import java.util.List;

public interface ForumRepDAO {
	
	void addForumRep(ForumRep r);
	List<ForumRep> viewForumRep();

}

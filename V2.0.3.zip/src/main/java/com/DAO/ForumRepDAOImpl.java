/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.Forum;
import com.Model.ForumRep;

/**
 * @author Admin
 *
 */
@Repository
public class ForumRepDAOImpl implements ForumRepDAO {

	/* (non-Javadoc)
	 * @see com.DAO.ForumRepDAO#addForumRep(com.Model.ForumRep)
	 */
	@Autowired
	SessionFactory sf;
	
	Session s;
	Transaction t;
	
	@Transactional
	public void addForumRep(ForumRep r) {
		// TODO Auto-generated method stub
		s = sf.openSession();
		t = s.beginTransaction();
		s.saveOrUpdate(r);
		t.commit();
	}

	/* (non-Javadoc)
	 * @see com.DAO.ForumRepDAO#viewForumRep()
	 */
	@Transactional
	public List<ForumRep> viewForumRep() {
		// TODO Auto-generated method stub
		List<ForumRep> l;
		s = sf.openSession();
		t = s.beginTransaction();
		l = (List<ForumRep>)s.createCriteria(ForumRep.class).list();
		return l;
	}

}

package com.DAO;

import java.util.List;
import com.Model.Forum;

public interface ForumDAO {
	
	void addForum(Forum f);
	List<Forum> viewForum();

}

package com.Controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.BlogDAO;
import com.DAO.ForumDAO;
import com.DAO.ForumRepDAO;
import com.DAO.UserDAO;
import com.Model.Blog;
import com.Model.Forum;
import com.Model.ForumRep;
import com.Model.User;

@Controller
public class BaseController {

	@Autowired
	UserDAO ud;
	@Autowired
	BlogDAO bd;
	@Autowired
	ForumDAO cd;
	@Autowired
	ForumRepDAO dd;

	@ModelAttribute("obj")
	public User getOb() {
		return new User();
	}

	@RequestMapping("/")
	public String gohome() {
		System.out.println("home");
		return "home";
	}

	@RequestMapping(value = "/save")
	public ModelAndView dohome1(@ModelAttribute("obj") User x, HttpServletRequest req) {
		ModelAndView m = new ModelAndView("home");
		ud.addUser(x);
		if (!x.getFile().isEmpty()) {
			String a = req.getSession().getServletContext().getRealPath("/");
			File f = new File(a + "\\resources\\assets\\upimages\\");
			if (!f.exists())
				f.mkdirs();
			Path path = Paths.get(a + "\\resources\\assets\\upimages\\" + x.getUname() + ".jpg");
			try {
				x.getFile().transferTo(new File(path.toString()));
				System.out.println(path.toString());
			} catch (Exception e) {
			}
			
		} else {
			m.setViewName("login");
			System.out.println("You failed to upload " + x.getUname() + " because the file was empty.");

		}
		return m;
	}
	User a;
	@RequestMapping("/view")
	public ModelAndView gopro(Principal p) {
		ModelAndView m = new ModelAndView("editprofile");
		m.addObject("data",ud.viewUserby(p.getName()));
		a=ud.viewUserby(p.getName());
		return m;
	}

	@RequestMapping("/edit/{youmail}")
	public ModelAndView doedit(@PathVariable String youmail){
		ModelAndView modelandview = new ModelAndView("editprofile2");
		modelandview.addObject("obj", a);
		return modelandview;
	}

	@RequestMapping("/editprofile2")
	public String goeditprofile2() {
		System.out.println("editprofile2");
		return "editprofile2";
	}
	
	@RequestMapping("/login")
	public String gologin() {
		System.out.println("login");
		return "login";
	}

	@RequestMapping("/chat")
	public String gochat() {
		System.out.println("chat");
		return "chat";
	}

	@RequestMapping("/userprofile")
	public String gouserprofile() {
		System.out.println("userprofile");
		return "userprofile";
	}
	
	/*=======================*Blog*========================*/

	
	@ModelAttribute("blo")
	public Blog getblo() {
		return new Blog();
	}
	
	@RequestMapping("/blog")
	public String goblog() {
		System.out.println("blog");
		return "blog";
	}
	@RequestMapping("/createblog")
	public String gocreateblog() {
		System.out.println("createblog");
		return "createblog";
	}
	@RequestMapping("/views")
	public ModelAndView goblo() {
		ModelAndView m = new ModelAndView("blog");
		m.addObject("text", bd.viewBlog());
		return m;
	}

	/*@RequestMapping("/bloginfo")
	public String gobloginfo() {
		System.out.println("bloginfo");
		return "bloginfo";
	}*/
	
	
	@RequestMapping(value = "/sav")
	public ModelAndView dohome1(@ModelAttribute("blo") Blog y, HttpServletRequest req) {
		ModelAndView m = new ModelAndView("home");
		bd.addBlog(y);
		if (!y.getFile().isEmpty()) {
			String a = req.getSession().getServletContext().getRealPath("/");
			File f = new File(a + "\\resources\\assets\\upimages\\");
			if (!f.exists())
				f.mkdirs();
			Path path = Paths.get(a + "\\resources\\assets\\upimages\\" + y.getName() + ".jpg");
			try {
				y.getFile().transferTo(new File(path.toString()));
				System.out.println("uploaded successfully");
			}
			catch (Exception e) {
			}
		} else {
			m.setViewName("createblog");
			System.out.println("You failed to upload " + y.getName() + " because the file was empty.");

		}
		return m;
	}

	
	/*=======================*Forum*========================*/
	
	@ModelAttribute("for")
	public Forum getfor() {
		return new Forum();
	}
	
	@ModelAttribute("foru")
	public ForumRep getforu() {
		return new ForumRep();
	}
	
	@RequestMapping("/forum")
	public String goforum() {
		System.out.println("forum");
		return "forum";
	}
	
	@RequestMapping("/createforum")
	public String gocreateforum() {
		System.out.println("createforum");
		return "createforum";
	}
	
	@RequestMapping(value = "/savf")
	public ModelAndView doforum1(@ModelAttribute("for") Forum z, HttpServletRequest req) {
		ModelAndView m = new ModelAndView("forum");
		cd.addForum(z);
		return m;
	}
	
	
	@RequestMapping("/viewss")
	public ModelAndView goforu() {
		ModelAndView m = new ModelAndView("forum");
		m.addObject("dtext",cd.viewForum());
		return m;
	}
	
	/*=======================*answer forum*========================*/
	
	@RequestMapping(value = "/savfo")
	public ModelAndView doforum2(@ModelAttribute("foru") ForumRep a, HttpServletRequest req) {
		ModelAndView m = new ModelAndView("forum");
		dd.addForumRep(a);
		return m;
	}

	
	
	
	/*=======================*Others*========================*/
	@RequestMapping("/services")
	public String goservices() {
		System.out.println("services");
		return "services";
	}

	@RequestMapping("about")
	public String goabout() {
		System.out.println("about");
		return "about";
	}
	
	@RequestMapping("/404")
	public String go404() {
		System.out.println("404");
		return "404";
	}

	/*=======================*Logout*========================*/
	 @RequestMapping("/logout")
	 public ModelAndView handleRequest(HttpServletRequest request,HttpServletResponse response){
		 ModelAndView view = new ModelAndView("home");
		 request.getSession().invalidate();
		 return view;
	 }

}

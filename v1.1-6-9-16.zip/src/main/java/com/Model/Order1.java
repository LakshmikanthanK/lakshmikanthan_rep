package com.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Order1 {
	
		@Column
		@NotEmpty(message="Type your First Name")
		private String fname;
	    @Column
		@NotEmpty(message="Type your Last Name")
		private String lname;
		@Id
		@Email
		@Column
		@NotEmpty(message="Type your Email")
		private String email;
		@Column
		@NotEmpty(message="Type your Product Code")
		private String code;
		@Column
		@NotEmpty(message="Type your PurchaseDetails")
		private String purchase;
		public String getFname() {
			return fname;
		}
		public void setFname(String fname) {
			this.fname = fname;
		}
		public String getLname() {
			return lname;
		}
		public void setLname(String lname) {
			this.lname = lname;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getPurchase() {
			return purchase;
		}
		public void setPurchase(String purchase) {
			this.purchase = purchase;
		}
		
		
	
	
	

}

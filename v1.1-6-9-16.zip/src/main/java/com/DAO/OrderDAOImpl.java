package com.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Model.Order1;

@Repository
public class OrderDAOImpl implements OrderDAO{

	@Autowired
	SessionFactory sf; 
	@Override
	
	public void addOrder1(Order1 c) {
		// TODO Auto-generated method stub
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		s.saveOrUpdate(c);
		t.commit();
		
		
	}

	@Override
	public List<Order1> viewOrder1() {
		// TODO Auto-generated method stub
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		List<Order1> l=(List<Order1>)s.createCriteria(Order1.class).list();
		t.commit();
		
		return l;
	}

	@Override
	public Order1 viewOrder1ByEmail(String email) {
		// TODO Auto-generated method stub
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("from Order1 where email=:email");
		q.setParameter("email", email);
		return (Order1)q.uniqueResult();
				
	}
	

}

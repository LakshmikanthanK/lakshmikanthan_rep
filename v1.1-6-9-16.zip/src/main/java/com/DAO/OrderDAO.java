package com.DAO;

import java.util.List;

import com.Model.Order1;


public interface OrderDAO {
	
	void addOrder1(Order1 c);
	List<Order1> viewOrder1();
	Order1 viewOrder1ByEmail(String email);	

}

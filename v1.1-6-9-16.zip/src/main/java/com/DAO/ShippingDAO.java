package com.DAO;

import java.util.List;

import com.Model.Shipping;

public interface ShippingDAO {

	void addShipping(Shipping c);
	List<Shipping> viewShipping();
	Shipping viewShippingByEmail(String email);	
}

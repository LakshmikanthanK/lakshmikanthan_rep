package com.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.Model.Shipping;

@Repository
public class ShippingDAOImpl implements ShippingDAO{

	@Autowired
	SessionFactory sf; 
	@Override
	
	public void addShipping(Shipping c) {
		// TODO Auto-generated method stub
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		s.saveOrUpdate(c);
		t.commit();
		
		
	}

	@Override
	public List<Shipping> viewShipping() {
		// TODO Auto-generated method stub
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		List<Shipping> l=(List<Shipping>)s.createCriteria(Shipping.class).list();
		t.commit();
		
		return l;
	}

	@Override
	public Shipping viewShippingByEmail(String email) {
		// TODO Auto-generated method stub
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("from Shipping where email=:email");
		q.setParameter("email", email);
		return (Shipping)q.uniqueResult();
				
	}

	

}

package com.DAO;

import java.util.List;

import com.Model.ProductModel_1 ;

public interface ProductDAO { 
	void addProduct(ProductModel_1  p);
    void viewProduct(String code );
    void deleteProduct(ProductModel_1  p);
    void editProduct(ProductModel_1  p);
    List<ProductModel_1 >ViewProductModel();
    ProductModel_1  viewProductby(String code);
}
